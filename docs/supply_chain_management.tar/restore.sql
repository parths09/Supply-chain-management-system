--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8 (Ubuntu 16.8-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.6 (Ubuntu 16.6-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE supply_chain_management;
--
-- Name: supply_chain_management; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE supply_chain_management WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_IN';


ALTER DATABASE supply_chain_management OWNER TO postgres;

\connect supply_chain_management

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: add_existing_products(character varying, numeric, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_existing_products(IN u_name character varying, IN price numeric, IN p_name character varying)
    LANGUAGE plpgsql
    AS $$
declare 
	sup_id bigint;
	prod_id bigint;
begin 
	select supplier_id into sup_id from suppliers where username=u_name;
	select product_id into prod_id from products where name=p_name;

	if exists(select * from prices where product_id = prod_id and supplier_id= sup_id) then 
		update prices set active=true where product_id = prod_id and supplier_id= sup_id;
		update prices set unit_price=price where product_id = prod_id and supplier_id= sup_id;
	else 
		insert into prices (product_id, supplier_id, unit_price,active) VALUES
		(prod_id,sup_id,price,true);
	end if;
end;
$$;


ALTER PROCEDURE public.add_existing_products(IN u_name character varying, IN price numeric, IN p_name character varying) OWNER TO postgres;

--
-- Name: add_new_products(character varying, numeric, character varying, text, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_new_products(IN u_name character varying, IN price numeric, IN p_name character varying, IN pdescription text DEFAULT NULL::text, IN pcategory text DEFAULT NULL::text)
    LANGUAGE plpgsql
    AS $$
declare 
	sup_id bigint;
	prod_id bigint;
begin 
	select supplier_id into sup_id from suppliers where username=u_name;
	select product_id+1 into prod_id from products order by product_id desc limit 1;
	--raise notice 's_id : % ,p_id : %',sup_id,prod_id;
	insert into  products (product_id, name, description, category) VALUES
	(prod_id,p_name,pdescription,pcategory);
	insert into prices (product_id, supplier_id, unit_price,active) VALUES
	(prod_id,sup_id,price,true);
end;
$$;


ALTER PROCEDURE public.add_new_products(IN u_name character varying, IN price numeric, IN p_name character varying, IN pdescription text, IN pcategory text) OWNER TO postgres;

--
-- Name: add_procurement(integer, integer, date, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_procurement(IN req_id integer, IN quantity integer, IN orderdate date, IN deliverydate date)
    LANGUAGE plpgsql
    AS $$
declare 
	inv_id int;
begin 
	select i.inventory_id into inv_id from inventory as i 
	join (select * from requests where request_id = req_id) as r 
	on i.supplier_id=r.supplier_id and i.product_id=r.product_id and i.warehouse_id=r.warehouse_id;
	--raise notice 'i_id : %',inv_id;
	
	update requests set approval ='Accepted' where request_id =req_id;

	insert into procurements (inventory_id,quantity,order_date,delivery_date,status) VALUES
	(inv_id,Quantity,orderDate,deliveryDate,'Processing');
	
end;
$$;


ALTER PROCEDURE public.add_procurement(IN req_id integer, IN quantity integer, IN orderdate date, IN deliverydate date) OWNER TO postgres;

--
-- Name: decline_request(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.decline_request(IN req_id integer)
    LANGUAGE plpgsql
    AS $$
begin 
	update requests set approval ='Denied' where request_id =req_id;
end;
$$;


ALTER PROCEDURE public.decline_request(IN req_id integer) OWNER TO postgres;

--
-- Name: delete_products_supplier(bigint, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.delete_products_supplier(IN p_id bigint, IN u_name character varying)
    LANGUAGE plpgsql
    AS $$
declare 
	sup_id bigint;
begin 
	select supplier_id into sup_id from suppliers where u_name = username;
	-- raise notice 'id : %',sup_id;
	update prices set active=false where product_id = p_id and supplier_id= sup_id;

end;
$$;


ALTER PROCEDURE public.delete_products_supplier(IN p_id bigint, IN u_name character varying) OWNER TO postgres;

--
-- Name: get_incoming_procurements(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_incoming_procurements(w_id integer) RETURNS TABLE(inventory_id bigint, quantity integer, order_date date, delivery_date date, status character varying, product_name character varying, supplier_name character varying)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select p.inventory_id,p.quantity,p.order_date,p.delivery_date,p.status,pr.name as product_name,s.supplier_name
	from procurements p
	join inventory i on i.inventory_id = p.inventory_id
	join products pr on pr.product_id = i.product_id
	join suppliers s on s.supplier_id = i.supplier_id
	where i.warehouse_id = w_id and p.status in ('In transit','Processing');
end;
$$;


ALTER FUNCTION public.get_incoming_procurements(w_id integer) OWNER TO postgres;

--
-- Name: get_low_stock(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_low_stock(w_id integer) RETURNS TABLE(inventory_id integer, supplier_id bigint, product_id bigint, product_name character varying, supplier_name character varying, quantity_in_stock integer, reorder_level integer, alert boolean)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select i.inventory_id,i.supplier_id,i.product_id,p.name as product_name,s.supplier_name,i.quantity_in_stock,i.reorder_level,i.alert
	from inventory i
	join products p on p.product_id = i.product_id
	join suppliers s on s.supplier_id = i.supplier_id
	where warehouse_id = w_id and i.quantity_in_stock<=i.reorder_level;
end;
$$;


ALTER FUNCTION public.get_low_stock(w_id integer) OWNER TO postgres;

--
-- Name: get_order_date(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_order_date(trk character varying) RETURNS date
    LANGUAGE plpgsql
    AS $$
declare
orderdate date;
begin 
	select o.order_date  into orderdate
	from shippings s
	join order_details od on od.shipping_id = s.shipping_id
	join orders o on o.order_id = od.order_id
	where s.tracking_number = trk;
	return orderdate;
end;
$$;


ALTER FUNCTION public.get_order_date(trk character varying) OWNER TO postgres;

--
-- Name: get_orders(bigint, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_orders(id bigint DEFAULT NULL::bigint, u_name character varying DEFAULT NULL::character varying) RETURNS TABLE(tracking_number character varying, product_name character varying, quantity integer, amount numeric, status character varying)
    LANGUAGE plpgsql
    AS $$
declare 
	cus_id bigint;

begin 
	cus_id = coalesce(id,(select customer_id from customers where username=u_name));
	return query
	select co.tracking_number,co.name,co.quantity,
	co.amount,co.shipping_status from customer_orders as co where customer_id = cus_id;

end;
$$;


ALTER FUNCTION public.get_orders(id bigint, u_name character varying) OWNER TO postgres;

--
-- Name: get_procurements_supplier(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_procurements_supplier(sup_name character varying) RETURNS TABLE(warehouse_name character varying, warehouse_location character varying, quantity integer, order_date date, delivery_date date, status character varying, product_name character varying)
    LANGUAGE plpgsql
    AS $$
begin 
	return query
	select w.name,w.location,p.quantity,p.order_date,p.delivery_date,p.status,pr.name
	from procurements p
	join inventory i on i.inventory_id = p.inventory_id
	join products pr on pr.product_id = i.product_id
	join suppliers s on s.supplier_id = i.supplier_id
	join warehouses w on i.warehouse_id = w.warehouse_id
	where s.username = sup_name ;
end;
$$;


ALTER FUNCTION public.get_procurements_supplier(sup_name character varying) OWNER TO postgres;

--
-- Name: get_product_details(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_product_details(trk character varying) RETURNS TABLE(order_id bigint, product_name character varying, product_description text, supplier_name character varying, supplier_address text, quantity integer, price numeric, shipping_address text, shipping_status character varying, order_date date, expected_delivery date)
    LANGUAGE plpgsql
    AS $$
begin
	return query
	select od.order_id,p.name as product_name,p.description as product_description,sup.supplier_name as supplier_name,
	sup.address as supplier_address,od.quantity,od.amount as price,c.shipping_address,s.shipping_status,o.order_date,s.delivery_date
	from shippings s
	join order_details od on od.shipping_id=s.shipping_id
	join orders o on od.order_id = o.order_id
	join customers c on c.customer_id = o.customer_id
	join inventory i on i.inventory_id = od.inventory_id
	join products p on p.product_id = i.product_id
	join suppliers sup on sup.supplier_id = i.supplier_id
	where s.tracking_number=trk;
end;
$$;


ALTER FUNCTION public.get_product_details(trk character varying) OWNER TO postgres;

--
-- Name: get_requests_supplier(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_requests_supplier(sup_name character varying) RETURNS TABLE(id integer, w_id integer, warehouse_name character varying, warehouse_location character varying, quantity integer, product_name character varying, contact character varying, unit_price numeric, total numeric)
    LANGUAGE plpgsql
    AS $$
begin
	return query
	select r.request_id,w.warehouse_id,w.name,w.location,r.quantity,p.name,r.contact_email,r.unit_price,(r.unit_price * r.quantity)
	from requests as r 
	join (select * from suppliers where username=sup_name) as s on r.supplier_id = s.supplier_id
	join warehouses as w on w.warehouse_id=r.warehouse_id
	join products as p on p.product_id=r.product_id
	where r.approval in('Pending');
end;
$$;


ALTER FUNCTION public.get_requests_supplier(sup_name character varying) OWNER TO postgres;

--
-- Name: get_shipment_details(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_shipment_details(w_id integer) RETURNS TABLE(shp_id bigint, move_to integer, shipping_status character varying, tracking_number character varying, delivery_date date)
    LANGUAGE plpgsql
    AS $$

begin 

	return query
	with curr_shipment as (select distinct shipping_id, first_value (curr_warehouse) over w as curr_warehouse,
	first_value (next_warehouse) over w as next_warehouse
	
	from shipping_details 
	window w as (partition by shipping_id order by detail_id desc))
	
	select cs.shipping_id,next_warehouse, s.shipping_status,s.tracking_number,s.delivery_date
	from curr_shipment as cs
	join shippings as s on cs.shipping_id =s.shipping_id
	where cs.curr_warehouse=w_id and s.shipping_status in ('Shipped','Pending','Processing',null);
	
end;
$$;


ALTER FUNCTION public.get_shipment_details(w_id integer) OWNER TO postgres;

--
-- Name: get_supplier_products(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_supplier_products(u_name character varying) RETURNS TABLE(name character varying, id bigint, description text, price numeric, category text)
    LANGUAGE plpgsql
    AS $$

begin 
	return query
	
	select p.name,p.product_id,p.description,ps.unit_price,p.category
	from products as  p join prices as  ps on p.product_id = ps.product_id
	join suppliers  as s on ps.supplier_id = s.supplier_id where s.username = u_name and ps.active=true;

end;
$$;


ALTER FUNCTION public.get_supplier_products(u_name character varying) OWNER TO postgres;

--
-- Name: get_tracking(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_tracking(trk character varying) RETURNS TABLE(shipping_id bigint, date date, currently_in integer, move_to integer)
    LANGUAGE plpgsql
    AS $$
begin 

	return query
	select s.shipping_id,sd.shipping_date,sd.curr_warehouse,sd.next_warehouse
	from shippings s
	join shipping_details sd on s.shipping_id = sd.shipping_id
	where s.tracking_number = trk;
	
end;
$$;


ALTER FUNCTION public.get_tracking(trk character varying) OWNER TO postgres;

--
-- Name: get_warehouse_products(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_warehouse_products(w_id integer) RETURNS TABLE(inventory_id integer, product_name character varying, supplier_name character varying, quantity_in_stock integer, reorder_level integer)
    LANGUAGE plpgsql
    AS $$

begin

	return query
	select i.inventory_id, p.name as product_name, s.supplier_name as supplier_name , i.quantity_in_stock,i.reorder_level
	from inventory as i
	join products p on p.product_id = i.product_id
	join suppliers s on s.supplier_id = i.supplier_id
	where i.warehouse_id=w_id;
	
end;
$$;


ALTER FUNCTION public.get_warehouse_products(w_id integer) OWNER TO postgres;

--
-- Name: insert_customer(character varying, character varying, character varying, smallint, character varying, character varying, integer, text, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_customer(IN username character varying, IN first_name character varying, IN last_name character varying, IN age smallint, IN phone_number character varying, IN email_id character varying, IN pincode integer, IN billing_address text, IN shipping_address text)
    LANGUAGE plpgsql
    AS $$

declare 
	customerId bigint;
	
begin 
	select coalesce(max(customer_id), 0) + 1 into customerId from customers;
	--raise notice'id : %',customerId;
	insert into customers(customer_id, username,first_name,last_name, age, phone_number, email_id, pincode, billing_address, shipping_address) values
	(customerId,username,first_name,last_name, age, phone_number, email_id, pincode, billing_address, shipping_address);
end;
$$;


ALTER PROCEDURE public.insert_customer(IN username character varying, IN first_name character varying, IN last_name character varying, IN age smallint, IN phone_number character varying, IN email_id character varying, IN pincode integer, IN billing_address text, IN shipping_address text) OWNER TO postgres;

--
-- Name: insert_supplier(character varying, character varying, character varying, character varying, integer, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_supplier(IN username character varying, IN name character varying, IN phone_number character varying, IN email_id character varying, IN pincode integer, IN address text)
    LANGUAGE plpgsql
    AS $$

declare 
	supplierId bigint;
	
begin 
	select coalesce(max(supplier_id), 0) + 1 into supplierId from suppliers;
	--raise notice'id : %',supplierId;
	insert into suppliers (supplier_id,username, supplier_name, phone_number, email_id, address, pincode) values
	(supplierID,username,name,phone_number,email_id,address,pincode);
end;
$$;


ALTER PROCEDURE public.insert_supplier(IN username character varying, IN name character varying, IN phone_number character varying, IN email_id character varying, IN pincode integer, IN address text) OWNER TO postgres;

--
-- Name: notify_customer_shipment(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.notify_customer_shipment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
message1 text;
trk varchar(15);
c_id bigint;

begin
	if new.shipping_status='Shipped' then
		select s.tracking_number,o.customer_id into trk,c_id
		from shippings s
		join order_details od on od.shipping_id = s.shipping_id
		join orders o on o.order_id = od.order_id
		where s.shipping_id = new.shipping_id;
			
		-- Add notification
		message1:=format('Your shipment with tracking number %s has been SHIPPED.',trk);
		
		insert into notifications(request_id,recipent_id,recipent_type,context,message) 
		values (new.shipping_id,c_id,'Customer','ShipmentShipped',message1);

	elsif new.shipping_status = 'Delivered' then
		select s.tracking_number,o.customer_id into trk,c_id
		from shippings s
		join order_details od on od.shipping_id = s.shipping_id
		join orders o on o.order_id = od.order_id
		where s.shipping_id = new.shipping_id;
			
		-- Add notification
		message1:=format('Your shipment with tracking number %s has been DELIVERED',trk);
		
		insert into notifications(request_id,recipent_id,recipent_type,context,message) 
		values (new.shipping_id,c_id,'Customer','ShipmentDelivered',message1);

	elsif new.shipping_status = 'Out for Delivery' then
		select s.tracking_number,o.customer_id into trk,c_id
		from shippings s
		join order_details od on od.shipping_id = s.shipping_id
		join orders o on o.order_id = od.order_id
		where s.shipping_id = new.shipping_id;
		
		-- Add notification
		message1:=format('Your shipment with tracking number %s is Out for Delivery.',trk);
		
		insert into notifications(request_id,recipent_id,recipent_type,context,message) 
		values (new.shipping_id,c_id,'Customer','ShipmentOutforDelivery',message1);
	
	end if;
	return new;
end;
$$;


ALTER FUNCTION public.notify_customer_shipment() OWNER TO postgres;

--
-- Name: notify_procurement(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.notify_procurement() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
message1 text;
message2 text;
p_name varchar(50);
s_name varchar(150);
w_name varchar(50);
s_id bigint;
p_id bigint;
w_id integer;
qty integer;

begin
	if new.status='Delivered' then
	select pr.quantity, p.name,p.product_id,s.supplier_name,s.supplier_id,w.warehouse_id,w.name into qty,p_name,p_id,s_name,s_id,w_id,w_name
	from procurements pr
	join inventory i on pr.inventory_id = i.inventory_id
	join products p on p.product_id = i.product_id
	join suppliers s on s.supplier_id = i.supplier_id
	join warehouses w on w.warehouse_id = i.warehouse_id
	where pr.procurement_id = new.procurement_id;

	-- Change stock in inventory
	update inventory set quantity_in_stock = quantity_in_stock+qty
	where inventory_id=new.inventory_id;

	-- Change alert in inventory
	update inventory set alert = true 
	where inventory_id=new.inventory_id and alert = false;

	-- Add notification
	message1:=format('Your request for %s %s from %s has been DELIVERED.',qty,p_name,s_name);
	message2:=format('Procurement for %s %s from %s has been COMPLETED.',qty,p_name,w_name);
	
	insert into notifications(request_id,recipent_id,recipent_type,context,message) 
	values (new.procurement_id,w_id,'Manager','ProcurementDelivered',message1), 
		(new.procurement_id,s_id,'Supplier','ProcurementDelivered',message2);
	end if;
	return new;
end;
$$;


ALTER FUNCTION public.notify_procurement() OWNER TO postgres;

--
-- Name: update_products_supplier(bigint, character varying, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.update_products_supplier(IN p_id bigint, IN u_name character varying, IN price numeric)
    LANGUAGE plpgsql
    AS $$
declare 
	sup_id bigint;
begin 
	select supplier_id into sup_id from suppliers where username=u_name;
	--raise notice 'id : %',sup_id;
	update prices set unit_price=price where product_id = p_id and supplier_id= sup_id;
end;
$$;


ALTER PROCEDURE public.update_products_supplier(IN p_id bigint, IN u_name character varying, IN price numeric) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    table_id bigint
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory (
    inventory_id integer NOT NULL,
    product_id bigint NOT NULL,
    supplier_id bigint NOT NULL,
    warehouse_id integer NOT NULL,
    quantity_in_stock integer NOT NULL,
    reorder_level integer,
    alert boolean DEFAULT true NOT NULL,
    CONSTRAINT inventory_quantity_in_stock_check CHECK ((quantity_in_stock >= 0))
);


ALTER TABLE public.inventory OWNER TO postgres;

--
-- Name: order_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_details (
    detail_id integer NOT NULL,
    order_id bigint NOT NULL,
    inventory_id bigint NOT NULL,
    shipping_id bigint NOT NULL,
    quantity integer NOT NULL,
    amount numeric(10,2),
    CONSTRAINT order_details_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT order_details_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.order_details OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    order_id bigint NOT NULL,
    customer_id bigint NOT NULL,
    order_date date NOT NULL,
    total_amount numeric(10,2),
    order_status character varying(15) DEFAULT 'pending'::character varying NOT NULL,
    CONSTRAINT orders_order_status_check CHECK (((order_status)::text = ANY (ARRAY[('Pending'::character varying)::text, ('Confirmed'::character varying)::text, ('On the way'::character varying)::text, ('Completed'::character varying)::text])))
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    product_id bigint NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    category text
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: shippings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shippings (
    shipping_id bigint NOT NULL,
    delivery_date date,
    tracking_number character varying(15) NOT NULL,
    shipping_status character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    last_updated date,
    CONSTRAINT shippings_shipping_status_check CHECK (((shipping_status)::text = ANY (ARRAY[('Pending'::character varying)::text, ('Processing'::character varying)::text, ('Shipped'::character varying)::text, ('In Transit'::character varying)::text, ('Out for Delivery'::character varying)::text, ('Delivered'::character varying)::text])))
);


ALTER TABLE public.shippings OWNER TO postgres;

--
-- Name: customer_orders; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.customer_orders AS
 SELECT o.customer_id,
    shp.tracking_number,
    p.name,
    od.quantity,
    od.amount,
    shp.shipping_status,
    shp.delivery_date
   FROM public.products p,
    public.order_details od,
    public.orders o,
    public.inventory i,
    public.shippings shp
  WHERE ((o.order_id = od.order_id) AND (od.shipping_id = shp.shipping_id) AND (od.inventory_id = i.inventory_id) AND (i.product_id = p.product_id));


ALTER VIEW public.customer_orders OWNER TO postgres;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id bigint NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    age smallint NOT NULL,
    phone_number character varying(15) NOT NULL,
    email_id character varying(30) NOT NULL,
    pincode integer NOT NULL,
    billing_address text,
    shipping_address text,
    CONSTRAINT customers_age_check CHECK ((age >= 18))
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employee_id bigint NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    warehouse_id bigint NOT NULL,
    phone_number character varying(15) NOT NULL,
    email_id character varying(50) NOT NULL,
    salary numeric(10,2),
    role character varying(20) NOT NULL,
    CONSTRAINT employees_role_check CHECK (((role)::text = ANY (ARRAY[('worker'::character varying)::text, ('manager'::character varying)::text])))
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_inventory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_inventory_id_seq OWNER TO postgres;

--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_inventory_id_seq OWNED BY public.inventory.inventory_id;


--
-- Name: managers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.managers (
    manager_id bigint NOT NULL,
    warehouse_id bigint NOT NULL,
    username character varying(150)
);


ALTER TABLE public.managers OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    notification_id integer NOT NULL,
    request_id integer NOT NULL,
    recipent_id bigint NOT NULL,
    recipent_type character varying(20) NOT NULL,
    message text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    context character varying(30),
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT notifications_context_check CHECK (((context)::text = ANY (ARRAY[('RequestProcurement'::character varying)::text, ('RequestApproval'::character varying)::text, ('ProcurementDelivered'::character varying)::text, ('ProcurementArriving'::character varying)::text, ('ShipmentDelivered'::character varying)::text, ('ShipmentShipped'::character varying)::text, ('ShipmentOutforDelivery'::character varying)::text]))),
    CONSTRAINT notifications_recipent_type_check CHECK (((recipent_type)::text = ANY (ARRAY[('Customer'::character varying)::text, ('Manager'::character varying)::text, ('Supplier'::character varying)::text])))
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notifications_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_notification_id_seq OWNER TO postgres;

--
-- Name: notifications_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notifications_notification_id_seq OWNED BY public.notifications.notification_id;


--
-- Name: order_details_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_details_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_details_detail_id_seq OWNER TO postgres;

--
-- Name: order_details_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_details_detail_id_seq OWNED BY public.order_details.detail_id;


--
-- Name: prices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prices (
    product_id bigint,
    supplier_id bigint,
    unit_price numeric(10,2) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    CONSTRAINT prices_unit_price_check CHECK ((unit_price > (0)::numeric))
);


ALTER TABLE public.prices OWNER TO postgres;

--
-- Name: procurements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.procurements (
    procurement_id integer NOT NULL,
    inventory_id bigint NOT NULL,
    quantity integer NOT NULL,
    order_date date NOT NULL,
    delivery_date date NOT NULL,
    status character varying(20) DEFAULT 'Processing'::character varying NOT NULL,
    last_updated date,
    CONSTRAINT procurements_status_check CHECK (((status)::text = ANY (ARRAY[('Delivered'::character varying)::text, ('In transit'::character varying)::text, ('Processing'::character varying)::text])))
);


ALTER TABLE public.procurements OWNER TO postgres;

--
-- Name: procurements_procurement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.procurements_procurement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.procurements_procurement_id_seq OWNER TO postgres;

--
-- Name: procurements_procurement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.procurements_procurement_id_seq OWNED BY public.procurements.procurement_id;


--
-- Name: requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requests (
    request_id integer NOT NULL,
    product_id bigint NOT NULL,
    supplier_id bigint NOT NULL,
    warehouse_id integer NOT NULL,
    quantity integer NOT NULL,
    contact_email character varying(50),
    unit_price numeric(10,2) NOT NULL,
    approval character varying(20) DEFAULT 'Pending'::character varying NOT NULL,
    CONSTRAINT requests_approval_check CHECK (((approval)::text = ANY (ARRAY[('Pending'::character varying)::text, ('Accepted'::character varying)::text, ('Denied'::character varying)::text])))
);


ALTER TABLE public.requests OWNER TO postgres;

--
-- Name: requests_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.requests_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.requests_request_id_seq OWNER TO postgres;

--
-- Name: requests_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.requests_request_id_seq OWNED BY public.requests.request_id;


--
-- Name: shipping_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipping_details (
    detail_id integer NOT NULL,
    shipping_id bigint NOT NULL,
    shipping_date date,
    curr_warehouse integer NOT NULL,
    next_warehouse integer
);


ALTER TABLE public.shipping_details OWNER TO postgres;

--
-- Name: shipping_details_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipping_details_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shipping_details_detail_id_seq OWNER TO postgres;

--
-- Name: shipping_details_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipping_details_detail_id_seq OWNED BY public.shipping_details.detail_id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    supplier_id bigint NOT NULL,
    username character varying(150) NOT NULL,
    supplier_name character varying(150) NOT NULL,
    phone_number character varying(15) NOT NULL,
    email_id character varying(30) NOT NULL,
    address text,
    pincode integer NOT NULL
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    warehouse_id integer NOT NULL,
    name character varying(50) NOT NULL,
    location character varying(255),
    phone_number character varying(15),
    pincode integer NOT NULL
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: inventory inventory_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory ALTER COLUMN inventory_id SET DEFAULT nextval('public.inventory_inventory_id_seq'::regclass);


--
-- Name: notifications notification_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications ALTER COLUMN notification_id SET DEFAULT nextval('public.notifications_notification_id_seq'::regclass);


--
-- Name: order_details detail_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details ALTER COLUMN detail_id SET DEFAULT nextval('public.order_details_detail_id_seq'::regclass);


--
-- Name: procurements procurement_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurements ALTER COLUMN procurement_id SET DEFAULT nextval('public.procurements_procurement_id_seq'::regclass);


--
-- Name: requests request_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests ALTER COLUMN request_id SET DEFAULT nextval('public.requests_request_id_seq'::regclass);


--
-- Name: shipping_details detail_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_details ALTER COLUMN detail_id SET DEFAULT nextval('public.shipping_details_detail_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3709.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3711.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3713.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, table_id) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, table_id) FROM '$$PATH$$/3715.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3716.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3719.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customer_id, username, first_name, last_name, age, phone_number, email_id, pincode, billing_address, shipping_address) FROM stdin;
\.
COPY public.customers (customer_id, username, first_name, last_name, age, phone_number, email_id, pincode, billing_address, shipping_address) FROM '$$PATH$$/3726.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3727.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3729.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3731.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3733.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employee_id, first_name, last_name, warehouse_id, phone_number, email_id, salary, role) FROM stdin;
\.
COPY public.employees (employee_id, first_name, last_name, warehouse_id, phone_number, email_id, salary, role) FROM '$$PATH$$/3734.dat';

--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory (inventory_id, product_id, supplier_id, warehouse_id, quantity_in_stock, reorder_level, alert) FROM stdin;
\.
COPY public.inventory (inventory_id, product_id, supplier_id, warehouse_id, quantity_in_stock, reorder_level, alert) FROM '$$PATH$$/3721.dat';

--
-- Data for Name: managers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.managers (manager_id, warehouse_id, username) FROM stdin;
\.
COPY public.managers (manager_id, warehouse_id, username) FROM '$$PATH$$/3736.dat';

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (notification_id, request_id, recipent_id, recipent_type, message, is_read, context, created_at) FROM stdin;
\.
COPY public.notifications (notification_id, request_id, recipent_id, recipent_type, message, is_read, context, created_at) FROM '$$PATH$$/3737.dat';

--
-- Data for Name: order_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_details (detail_id, order_id, inventory_id, shipping_id, quantity, amount) FROM stdin;
\.
COPY public.order_details (detail_id, order_id, inventory_id, shipping_id, quantity, amount) FROM '$$PATH$$/3722.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (order_id, customer_id, order_date, total_amount, order_status) FROM stdin;
\.
COPY public.orders (order_id, customer_id, order_date, total_amount, order_status) FROM '$$PATH$$/3723.dat';

--
-- Data for Name: prices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.prices (product_id, supplier_id, unit_price, active) FROM stdin;
\.
COPY public.prices (product_id, supplier_id, unit_price, active) FROM '$$PATH$$/3740.dat';

--
-- Data for Name: procurements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.procurements (procurement_id, inventory_id, quantity, order_date, delivery_date, status, last_updated) FROM stdin;
\.
COPY public.procurements (procurement_id, inventory_id, quantity, order_date, delivery_date, status, last_updated) FROM '$$PATH$$/3741.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (product_id, name, description, category) FROM stdin;
\.
COPY public.products (product_id, name, description, category) FROM '$$PATH$$/3724.dat';

--
-- Data for Name: requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requests (request_id, product_id, supplier_id, warehouse_id, quantity, contact_email, unit_price, approval) FROM stdin;
\.
COPY public.requests (request_id, product_id, supplier_id, warehouse_id, quantity, contact_email, unit_price, approval) FROM '$$PATH$$/3743.dat';

--
-- Data for Name: shipping_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipping_details (detail_id, shipping_id, shipping_date, curr_warehouse, next_warehouse) FROM stdin;
\.
COPY public.shipping_details (detail_id, shipping_id, shipping_date, curr_warehouse, next_warehouse) FROM '$$PATH$$/3745.dat';

--
-- Data for Name: shippings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shippings (shipping_id, delivery_date, tracking_number, shipping_status, last_updated) FROM stdin;
\.
COPY public.shippings (shipping_id, delivery_date, tracking_number, shipping_status, last_updated) FROM '$$PATH$$/3725.dat';

--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (supplier_id, username, supplier_name, phone_number, email_id, address, pincode) FROM stdin;
\.
COPY public.suppliers (supplier_id, username, supplier_name, phone_number, email_id, address, pincode) FROM '$$PATH$$/3747.dat';

--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (warehouse_id, name, location, phone_number, pincode) FROM stdin;
\.
COPY public.warehouses (warehouse_id, name, location, phone_number, pincode) FROM '$$PATH$$/3748.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 3, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 36, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 18, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 23, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 42, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 9, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 21, true);


--
-- Name: inventory_inventory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_inventory_id_seq', 9, true);


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_notification_id_seq', 121, true);


--
-- Name: order_details_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_details_detail_id_seq', 339, true);


--
-- Name: procurements_procurement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.procurements_procurement_id_seq', 98, true);


--
-- Name: requests_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.requests_request_id_seq', 17, true);


--
-- Name: shipping_details_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipping_details_detail_id_seq', 526, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: customers customers_email_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_email_id_key UNIQUE (email_id);


--
-- Name: customers customers_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_phone_number_key UNIQUE (phone_number);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customer_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: employees employees_email_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_id_key UNIQUE (email_id);


--
-- Name: employees employees_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_phone_number_key UNIQUE (phone_number);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employee_id);


--
-- Name: inventory inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_pkey PRIMARY KEY (inventory_id);


--
-- Name: managers managers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_pkey PRIMARY KEY (manager_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: order_details order_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details
    ADD CONSTRAINT order_details_pkey PRIMARY KEY (detail_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (order_id);


--
-- Name: procurements procurements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurements
    ADD CONSTRAINT procurements_pkey PRIMARY KEY (procurement_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (product_id);


--
-- Name: requests requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_pkey PRIMARY KEY (request_id);


--
-- Name: shipping_details shipping_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_details
    ADD CONSTRAINT shipping_details_pkey PRIMARY KEY (detail_id);


--
-- Name: shippings shippings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shippings
    ADD CONSTRAINT shippings_pkey PRIMARY KEY (shipping_id);


--
-- Name: suppliers suppliers_email_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_email_id_key UNIQUE (email_id);


--
-- Name: suppliers suppliers_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_phone_number_key UNIQUE (phone_number);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplier_id);


--
-- Name: warehouses warehouses_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_phone_number_key UNIQUE (phone_number);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (warehouse_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: shippings notify_customer_shipment_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER notify_customer_shipment_trigger AFTER UPDATE ON public.shippings FOR EACH ROW EXECUTE FUNCTION public.notify_customer_shipment();


--
-- Name: procurements notify_procurement_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER notify_procurement_trigger AFTER UPDATE ON public.procurements FOR EACH ROW EXECUTE FUNCTION public.notify_procurement();


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employees employees_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(warehouse_id) ON DELETE SET NULL;


--
-- Name: inventory inventory_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE RESTRICT;


--
-- Name: inventory inventory_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id) ON DELETE RESTRICT;


--
-- Name: inventory inventory_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory
    ADD CONSTRAINT inventory_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(warehouse_id) ON DELETE RESTRICT;


--
-- Name: managers managers_manager_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_manager_id_fkey FOREIGN KEY (manager_id) REFERENCES public.employees(employee_id) ON DELETE SET NULL;


--
-- Name: managers managers_username_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_username_fkey FOREIGN KEY (username) REFERENCES public.auth_user(username) ON DELETE SET NULL;


--
-- Name: managers managers_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.managers
    ADD CONSTRAINT managers_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(warehouse_id) ON DELETE CASCADE;


--
-- Name: order_details order_details_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details
    ADD CONSTRAINT order_details_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES public.inventory(inventory_id) ON DELETE RESTRICT;


--
-- Name: order_details order_details_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details
    ADD CONSTRAINT order_details_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(order_id) ON DELETE RESTRICT;


--
-- Name: order_details order_details_shipping_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_details
    ADD CONSTRAINT order_details_shipping_id_fkey FOREIGN KEY (shipping_id) REFERENCES public.shippings(shipping_id) ON DELETE RESTRICT;


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id) ON DELETE CASCADE;


--
-- Name: prices prices_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- Name: prices prices_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id) ON DELETE CASCADE;


--
-- Name: procurements procurements_inventory_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.procurements
    ADD CONSTRAINT procurements_inventory_id_fkey FOREIGN KEY (inventory_id) REFERENCES public.inventory(inventory_id) ON DELETE CASCADE;


--
-- Name: requests requests_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(product_id) ON DELETE CASCADE;


--
-- Name: requests requests_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(supplier_id) ON DELETE CASCADE;


--
-- Name: requests requests_warehouse_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requests
    ADD CONSTRAINT requests_warehouse_id_fkey FOREIGN KEY (warehouse_id) REFERENCES public.warehouses(warehouse_id) ON DELETE CASCADE;


--
-- Name: shipping_details shipping_details_curr_warehouse_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_details
    ADD CONSTRAINT shipping_details_curr_warehouse_fkey FOREIGN KEY (curr_warehouse) REFERENCES public.warehouses(warehouse_id);


--
-- Name: shipping_details shipping_details_next_warehouse_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_details
    ADD CONSTRAINT shipping_details_next_warehouse_fkey FOREIGN KEY (next_warehouse) REFERENCES public.warehouses(warehouse_id);


--
-- Name: shipping_details shipping_details_shipping_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipping_details
    ADD CONSTRAINT shipping_details_shipping_id_fkey FOREIGN KEY (shipping_id) REFERENCES public.shippings(shipping_id);


--
-- Name: TABLE inventory; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.inventory TO customer;
GRANT SELECT,INSERT,UPDATE ON TABLE public.inventory TO manager;
GRANT SELECT ON TABLE public.inventory TO supplier;


--
-- Name: TABLE order_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.order_details TO customer;


--
-- Name: TABLE orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.orders TO customer;


--
-- Name: TABLE products; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.products TO customer;
GRANT SELECT ON TABLE public.products TO manager;
GRANT ALL ON TABLE public.products TO supplier;


--
-- Name: TABLE shippings; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.shippings TO customer;
GRANT SELECT ON TABLE public.shippings TO manager;


--
-- Name: TABLE customer_orders; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.customer_orders TO customer;


--
-- Name: TABLE customers; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.customers TO customer;


--
-- Name: TABLE employees; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.employees TO manager;


--
-- Name: SEQUENCE inventory_inventory_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.inventory_inventory_id_seq TO manager;


--
-- Name: TABLE managers; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.managers TO manager;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,UPDATE ON TABLE public.notifications TO customer;
GRANT SELECT,INSERT,UPDATE ON TABLE public.notifications TO manager;
GRANT SELECT,INSERT,UPDATE ON TABLE public.notifications TO supplier;


--
-- Name: SEQUENCE notifications_notification_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.notifications_notification_id_seq TO manager;


--
-- Name: TABLE prices; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.prices TO manager;
GRANT ALL ON TABLE public.prices TO supplier;


--
-- Name: TABLE procurements; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.procurements TO manager;
GRANT ALL ON TABLE public.procurements TO supplier;


--
-- Name: SEQUENCE procurements_procurement_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.procurements_procurement_id_seq TO supplier;


--
-- Name: TABLE requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.requests TO manager;
GRANT SELECT,UPDATE ON TABLE public.requests TO supplier;


--
-- Name: SEQUENCE requests_request_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.requests_request_id_seq TO manager;


--
-- Name: TABLE shipping_details; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.shipping_details TO customer;
GRANT SELECT ON TABLE public.shipping_details TO manager;


--
-- Name: TABLE suppliers; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.suppliers TO customer;
GRANT SELECT ON TABLE public.suppliers TO manager;
GRANT SELECT ON TABLE public.suppliers TO supplier;


--
-- Name: TABLE warehouses; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.warehouses TO manager;
GRANT SELECT ON TABLE public.warehouses TO supplier;


--
-- PostgreSQL database dump complete
--

